/*
	Write a program that will print out the first 10 numbers, their squares and their cubes
 */


public class Pr13 {
	
	public static void main (String[] args) {
		for (int i = 1; i <= 10; i++) {
			System.out.println(i + " " + i * i + " " + i * i * i);
		}
	}
}

