/*
	Change your program for writing EVEN and ODD so that it uses the else command.
 */


public class Pr23 {
	
	public static void main (String[] args) {
		int x = IBIO.inputInt("Enter a number: ");
		if (x % 2 == 0)
			System.out.println("EVEN");
		else
			System.out.println("ODD");
	}
}

